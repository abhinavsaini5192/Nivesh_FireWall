import{i as e,t}from"./chunks/url-SYPXZQlC.js";var n=[/password/i,/passcode/i,/otp/i,/one-time-code/i,/pin/i,/cvv/i,/cvc/i,/card.*number/i,/credit.*card/i,/cc-/i,/account.*number/i,/bank/i,/routing/i,/secret/i,/ssn/i,/token/i,/security.*code/i];function r(e){if(!e)return!1;let t=e.tagName.toLowerCase();if(t===`input`||t===`textarea`){let t=e,r=(t.type||``).toLowerCase();if(r===`password`||r===`hidden`)return!0;let i=`${t.name||``} ${t.id||``} ${t.placeholder||``} ${t.autocomplete||``}`;return n.some(e=>e.test(i))}return!1}function i(){if(typeof window>`u`||typeof window.getSelection!=`function`)return;let e=window.getSelection();if(!e||e.rangeCount===0||e.isCollapsed)return;let t=e.anchorNode,n=t instanceof Element?t:t?.parentElement??null;if(n&&(r(n)||r(n.closest(`input, textarea`))))return;let i=e.toString().trim();if(i)return i.slice(0,5e3).replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F]/g,``)}function a(e={}){let t=e.maxContentLength||5e3,n=``,r=``,a=``,o;if(typeof window<`u`&&window.location&&(n=window.location.href||``,r=window.location.origin||``),typeof document<`u`){a=(document.title||``).trim().slice(0,500);let e=document.querySelector(`meta[name="description"]`);e&&e.content&&(o=e.content.trim().slice(0,1e3))}let s=e.includeSelection===!1?void 0:i();return{pageUrl:n.slice(0,t),pageOrigin:r,pageTitle:a,selectedText:s,metaDescription:o,capturedAt:new Date().toISOString()}}var o=15e3,s=/\b(?:\d{4}[ -]?){3}\d{4}\b|\b\d{15,16}\b/g,c=/\b(?:cvv|cvc|security\s*code)[:\s=]+(\d{3,4})\b/gi,l=/\b(?:pin|atm\s*pin)[:\s=]+(\d{4,6})\b/gi;function u(e){return e?e.replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F\u007F-\u009F]/g,``).replace(/\r\n/g,`
`).replace(/\r/g,`
`).replace(/[ \t]+/g,` `).replace(/ +\n/g,`
`).replace(/\n +/g,`
`).replace(/\n{3,}/g,`

`).trim():``}function d(e){let t=!1,n=e.replace(s,e=>(t=!0,`[CARD_NUMBER_REDACTED_${e.length}]`));return n=n.replace(c,e=>(t=!0,`[CVV_REDACTED]`)),n=n.replace(l,e=>(t=!0,`[PIN_REDACTED]`)),{text:n,hadRedactions:t}}function f(e,t,n){if(t===`URL`)return{isValid:!0,status:`CAPTURED`,sanitizedText:``};if(!e||!e.trim())return{isValid:!1,status:t===`SELECTED_TEXT`?`NO_SELECTION`:`EMPTY_CONTENT`,error:t===`SELECTED_TEXT`?`No text selected on page.`:`No visible text found on page.`};let r=n||(t===`SELECTED_TEXT`?5e3:15e3);if(e.length>r)return{isValid:!1,status:`CONTENT_TOO_LARGE`,error:`Captured content length (${e.length} characters) exceeds safe limit of ${r} characters.`};let i=u(e);if(!i)return{isValid:!1,status:t===`SELECTED_TEXT`?`NO_SELECTION`:`EMPTY_CONTENT`,error:`Normalized content is empty.`};let{text:a}=d(i);return{isValid:!0,status:`CAPTURED`,sanitizedText:a}}var p=new Set([`script`,`style`,`noscript`,`template`,`svg`,`iframe`,`canvas`,`video`,`audio`,`object`,`embed`,`input`,`textarea`,`select`,`option`,`button`,`nav`,`footer`]);function m(e){if(!e||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`)return!0;let t=e.getAttribute(`style`)||``;if(/display\s*:\s*none/i.test(t)||/visibility\s*:\s*hidden/i.test(t)||/opacity\s*:\s*0(?![.\d])/i.test(t))return!0;if(typeof window<`u`&&typeof window.getComputedStyle==`function`)try{let t=window.getComputedStyle(e);if(t.display===`none`||t.visibility===`hidden`||t.visibility===`collapse`||t.opacity===`0`)return!0}catch{}return!1}function h(e){if(!e||!e.body)return{isValid:!1,status:`EMPTY_CONTENT`,error:`Document body is unavailable.`};let t=e.body,n=[],i=0;function a(e){if(!(i>22500)){if(e.nodeType===Node.TEXT_NODE){let t=(e.textContent||``).trim();t.length>0&&(n.push(t),i+=t.length);return}if(e.nodeType===Node.ELEMENT_NODE){let t=e,i=t.tagName.toLowerCase();if(p.has(i)||r(t)||m(t))return;for(let t=e.firstChild;t!==null;t=t.nextSibling)a(t);/^(p|div|section|article|h[1-6]|li|blockquote|tr)$/.test(i)&&n.push(`
`)}}}return a(t),f(n.join(` `),`CURRENT_PAGE`,o)}function g(e){if(!e||typeof e.getSelection!=`function`)return{isValid:!1,status:`NO_SELECTION`,error:`Window selection API unavailable.`};let t=e.getSelection();if(!t||t.rangeCount===0||t.isCollapsed)return{isValid:!1,status:`NO_SELECTION`,error:`No text is currently selected on the page.`};let n=t.anchorNode,i=n instanceof Element?n:n?.parentElement??null;return i&&(r(i)||r(i.closest(`input, textarea`)))?{isValid:!1,status:`NO_SELECTION`,error:`Selection originated inside a protected credential or financial field.`}:f(t.toString().trim(),`SELECTED_TEXT`)}var _=class{hostElement=null;shadowRoot=null;keydownHandler=null;currentPayload=null;callbacks;constructor(e){this.callbacks=e}render(e){if(this.destroy(),e.decision===`ALLOW`)return;this.currentPayload=e,this.hostElement=document.createElement(`div`),this.hostElement.id=`nivesh-firewall-root`,this.hostElement.style.cssText=`all: initial; position: relative; z-index: 2147483647;`,this.shadowRoot=this.hostElement.attachShadow({mode:`open`});let t=document.createElement(`style`);t.textContent=this.getOverlayStyles(),this.shadowRoot.appendChild(t);let n=document.createElement(`div`);n.className=`nivesh-container ${e.decision.toLowerCase()}`,e.decision===`INFORM`||e.decision===`WARN`?n.appendChild(this.buildBanner(e)):e.decision===`PAUSE`?n.appendChild(this.buildPauseModal(e)):e.decision===`BLOCK`&&n.appendChild(this.buildBlockModal(e)),this.shadowRoot.appendChild(n),document.body.appendChild(this.hostElement),this.setupAccessibility(n,e.decision)}buildBanner(e){let t=document.createElement(`div`);t.className=`nivesh-banner ${e.decision.toLowerCase()}`,t.setAttribute(`role`,`status`),t.setAttribute(`aria-live`,`polite`);let n=document.createElement(`div`);n.className=`banner-header`;let r=document.createElement(`span`);r.className=`brand-tag`,r.textContent=`NIVESH FIREWALL`;let i=document.createElement(`strong`);i.className=`banner-title`,i.textContent=e.decision===`WARN`?`⚠ Review Before Continuing`:`ℹ Nivesh Information`,n.appendChild(r),n.appendChild(i),t.appendChild(n);let a=document.createElement(`p`);a.className=`banner-body`,a.textContent=e.userMessage||e.primaryReason||`Review the information before proceeding.`,t.appendChild(a);let o=document.createElement(`div`);o.className=`banner-actions`;let s=document.createElement(`button`);s.className=`btn btn-primary`,s.textContent=e.decision===`WARN`?`Review Details`:`View Analysis`,s.addEventListener(`click`,()=>{this.callbacks.onOpenAnalysis(e.analysisId)});let c=document.createElement(`button`);return c.className=`btn btn-ghost`,c.textContent=`Dismiss`,c.addEventListener(`click`,()=>{this.destroy(),this.callbacks.onDismiss()}),o.appendChild(s),o.appendChild(c),t.appendChild(o),t}buildPauseModal(e){let t=document.createElement(`div`);t.className=`nivesh-backdrop`;let n=this.buildPauseModalElement(e);return t.appendChild(n),t}buildPauseModalElement(e){let t=document.createElement(`div`);t.className=`nivesh-modal pause`,t.setAttribute(`role`,`dialog`),t.setAttribute(`aria-modal`,`true`),t.setAttribute(`aria-labelledby`,`nivesh-pause-title`);let n=document.createElement(`div`);n.className=`modal-header`;let r=document.createElement(`span`);r.className=`decision-badge pause`,r.textContent=`⏸ ACTION PAUSED`;let i=document.createElement(`span`);i.className=`brand-tag`,i.textContent=`NIVESH FIREWALL`,n.appendChild(r),n.appendChild(i),t.appendChild(n);let a=document.createElement(`h2`);a.id=`nivesh-pause-title`,a.className=`modal-title`,a.textContent=`Action Paused Before Proceeding`;let o=document.createElement(`p`);o.className=`modal-description`,o.textContent=e.userMessage||e.primaryReason||`Nivesh recommends reviewing the available evidence before continuing.`,t.appendChild(a),t.appendChild(o);let s=document.createElement(`div`);s.className=`reason-grid`,e.identityStatus&&s.appendChild(this.buildGridItem(`Identity`,e.identityStatus)),e.evidenceStatus&&s.appendChild(this.buildGridItem(`Evidence`,e.evidenceStatus)),e.claimsCount&&e.claimsCount>0&&s.appendChild(this.buildGridItem(`Claims Evaluated`,`${e.claimsCount}`)),e.fingerprintMatch&&e.fingerprintMatch!==`NO_MATCH`&&s.appendChild(this.buildGridItem(`Pattern`,e.fingerprintMatch)),t.appendChild(s);let c=document.createElement(`div`);c.className=`modal-actions`;let l=document.createElement(`button`);l.className=`btn btn-secondary`,l.textContent=`Review Why (Open Details)`,l.addEventListener(`click`,()=>{this.callbacks.onOpenAnalysis(e.analysisId)});let u=document.createElement(`button`);u.className=`btn btn-ghost`,u.textContent=`Return to Page`,u.addEventListener(`click`,()=>{this.destroy(),this.callbacks.onReturn&&this.callbacks.onReturn(),this.callbacks.onDismiss()});let d=document.createElement(`button`);return d.className=`btn btn-outline`,d.textContent=`Continue After Confirmation`,d.addEventListener(`click`,()=>{this.showOverrideConfirmationDialog(e)}),c.appendChild(l),c.appendChild(u),c.appendChild(d),t.appendChild(c),t}buildBlockModal(e){let t=document.createElement(`div`);t.className=`nivesh-backdrop`;let n=document.createElement(`div`);n.className=`nivesh-modal block`,n.setAttribute(`role`,`alertdialog`),n.setAttribute(`aria-modal`,`true`),n.setAttribute(`aria-labelledby`,`nivesh-block-title`);let r=document.createElement(`div`);r.className=`modal-header`;let i=document.createElement(`span`);i.className=`decision-badge block`,i.textContent=`🛑 ACTION BLOCKED`;let a=document.createElement(`span`);a.className=`brand-tag`,a.textContent=`NIVESH FIREWALL`,r.appendChild(i),r.appendChild(a),n.appendChild(r);let o=document.createElement(`h2`);o.id=`nivesh-block-title`,o.className=`modal-title`,o.textContent=`Supported Interaction Blocked`;let s=document.createElement(`p`);if(s.className=`modal-description`,s.textContent=e.userMessage||`Nivesh Firewall blocked this supported interaction according to its protection policy.`,n.appendChild(o),n.appendChild(s),e.primaryReason&&e.primaryReason!==e.userMessage){let t=document.createElement(`div`);t.className=`grid-item`;let r=document.createElement(`span`);r.className=`grid-label`,r.textContent=`Primary Reason:`;let i=document.createElement(`p`);i.className=`modal-description`,i.textContent=e.primaryReason,t.appendChild(r),t.appendChild(i),n.appendChild(t)}let c=document.createElement(`div`);c.className=`modal-actions`;let l=document.createElement(`button`);l.className=`btn btn-primary`,l.textContent=`View Full Technical Analysis`,l.addEventListener(`click`,()=>{this.callbacks.onOpenAnalysis(e.analysisId)});let u=document.createElement(`button`);return u.className=`btn btn-ghost`,u.textContent=`Close Notification`,u.addEventListener(`click`,()=>{this.destroy(),this.callbacks.onReturn&&this.callbacks.onReturn(),this.callbacks.onDismiss()}),c.appendChild(l),c.appendChild(u),n.appendChild(c),t.appendChild(n),t}showOverrideConfirmationDialog(e){if(!this.shadowRoot)return;let t=this.shadowRoot.querySelector(`.nivesh-backdrop`);if(!t)return;t.innerHTML=``;let n=document.createElement(`div`);n.className=`nivesh-modal override-dialog`,n.setAttribute(`role`,`dialog`),n.setAttribute(`aria-modal`,`true`),n.setAttribute(`aria-labelledby`,`nivesh-override-title`);let r=document.createElement(`span`);r.className=`brand-tag`,r.textContent=`NIVESH CONFIRMATION REQUIRED`,n.appendChild(r);let i=document.createElement(`h3`);i.id=`nivesh-override-title`,i.className=`modal-title`,i.textContent=`Continue With This Action?`,n.appendChild(i);let a=document.createElement(`p`);a.className=`modal-description`,a.textContent=`Nivesh previously paused this action because additional verification was required. Confirming will allow this interaction to proceed.`,n.appendChild(a);let o=document.createElement(`div`);o.className=`modal-actions`;let s=document.createElement(`button`);s.className=`btn btn-ghost`,s.textContent=`Cancel`,s.addEventListener(`click`,()=>{t.innerHTML=``;let n=this.buildPauseModalElement(e);t.appendChild(n)});let c=document.createElement(`button`);c.className=`btn btn-danger`,c.textContent=`Confirm & Continue`,c.addEventListener(`click`,()=>{this.destroy(),this.callbacks.onConfirmOverride&&this.callbacks.onConfirmOverride(e.analysisId)}),o.appendChild(s),o.appendChild(c),n.appendChild(o),t.appendChild(n),s.focus()}buildGridItem(e,t){let n=document.createElement(`div`);n.className=`grid-item`;let r=document.createElement(`span`);r.className=`grid-label`,r.textContent=e;let i=document.createElement(`strong`);return i.className=`grid-value`,i.textContent=t,n.appendChild(r),n.appendChild(i),n}setupAccessibility(e,t){let n=e.querySelectorAll(`button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])`);n.length>0&&n[0].focus(),this.keydownHandler=e=>{if(e.key===`Escape`&&(t===`INFORM`||t===`WARN`)&&(this.destroy(),this.callbacks.onDismiss()),e.key===`Tab`&&n.length>1){let t=n[0],r=n[n.length-1];e.shiftKey&&document.activeElement===t?(r.focus(),e.preventDefault()):!e.shiftKey&&document.activeElement===r&&(t.focus(),e.preventDefault())}},document.addEventListener(`keydown`,this.keydownHandler)}destroy(){this.keydownHandler&&=(document.removeEventListener(`keydown`,this.keydownHandler),null),this.hostElement&&this.hostElement.parentNode&&this.hostElement.parentNode.removeChild(this.hostElement),this.hostElement=null,this.shadowRoot=null,this.currentPayload=null}getPayload(){return this.currentPayload}getOverlayStyles(){return`
      :host {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        color: #f8fafc;
        line-height: 1.5;
      }
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      .brand-tag {
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #94a3b8;
      }

      /* Non-blocking Banners (INFORM & WARN) */
      .nivesh-banner {
        position: fixed;
        top: 20px;
        right: 20px;
        width: 360px;
        max-width: calc(100vw - 40px);
        background: #0f172a;
        border: 1px solid #334155;
        border-radius: 10px;
        padding: 16px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.4);
        display: flex;
        flex-direction: column;
        gap: 10px;
        z-index: 2147483647;
        animation: niveshSlideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
      }
      .nivesh-banner.warn {
        border-color: #f59e0b;
        background: #1e1b18;
      }
      .banner-header {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .banner-title {
        font-size: 14px;
        color: #f8fafc;
      }
      .nivesh-banner.warn .banner-title {
        color: #fbbf24;
      }
      .banner-body {
        font-size: 12px;
        color: #cbd5e1;
        line-height: 1.4;
      }
      .banner-actions {
        display: flex;
        gap: 8px;
        margin-top: 4px;
      }

      /* Modal Overlays (PAUSE & BLOCK) */
      .nivesh-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 42, 0.85);
        backdrop-filter: blur(4px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        z-index: 2147483647;
        animation: niveshFadeIn 0.2s ease;
      }
      .nivesh-modal {
        background: #0f172a;
        border: 1px solid #334155;
        border-radius: 12px;
        width: 480px;
        max-width: 100%;
        padding: 24px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
        display: flex;
        flex-direction: column;
        gap: 16px;
      }
      .nivesh-modal.pause {
        border-color: #f97316;
      }
      .nivesh-modal.block {
        border-color: #ef4444;
      }
      .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .decision-badge {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        padding: 3px 8px;
        border-radius: 4px;
      }
      .decision-badge.pause {
        background: rgba(249, 115, 22, 0.2);
        color: #fb923c;
        border: 1px solid #f97316;
      }
      .decision-badge.block {
        background: rgba(239, 68, 68, 0.2);
        color: #f87171;
        border: 1px solid #ef4444;
      }
      .modal-title {
        font-size: 18px;
        font-weight: 700;
        color: #f8fafc;
      }
      .modal-description {
        font-size: 13px;
        color: #cbd5e1;
        line-height: 1.5;
      }
      .reason-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        background: #1e293b;
        padding: 12px;
        border-radius: 8px;
        border: 1px solid #334155;
      }
      .grid-item {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .grid-label {
        font-size: 10px;
        text-transform: uppercase;
        color: #94a3b8;
        font-weight: 600;
      }
      .grid-value {
        font-size: 12px;
        color: #f1f5f9;
        font-family: monospace;
      }
      .modal-actions {
        display: flex;
        gap: 10px;
        margin-top: 8px;
        flex-wrap: wrap;
      }

      /* Buttons */
      .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 8px 14px;
        font-size: 12px;
        font-weight: 600;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.15s ease;
        border: 1px solid transparent;
        text-decoration: none;
      }
      .btn-primary {
        background: #0ea5e9;
        color: #0f172a;
      }
      .btn-primary:hover {
        background: #38bdf8;
      }
      .btn-secondary {
        background: #1e293b;
        color: #f8fafc;
        border-color: #475569;
      }
      .btn-secondary:hover {
        background: #334155;
      }
      .btn-ghost {
        background: transparent;
        color: #94a3b8;
        border-color: #334155;
      }
      .btn-ghost:hover {
        background: #1e293b;
        color: #f8fafc;
      }
      .btn-outline {
        background: transparent;
        color: #fb923c;
        border-color: #f97316;
      }
      .btn-outline:hover {
        background: rgba(249, 115, 22, 0.15);
      }
      .btn-danger {
        background: #dc2626;
        color: #f8fafc;
      }
      .btn-danger:hover {
        background: #ef4444;
      }

      @keyframes niveshSlideIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      @keyframes niveshFadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
    `}};function v(e=document,t,n){if(!t&&(!n||n.length===0))return{matchedElement:null,matchConfidence:`NO_MATCH`,reason:`No explicit target URL or action reference provided in backend analysis.`};if(t&&t.trim()){let n=t.trim(),r=null;try{r=new URL(n)}catch{}if(r){let t=Array.from(e.querySelectorAll(`a[href]`)).filter(e=>{try{let t=new URL(e.href,window.location.href);return t.origin.toLowerCase()===r.origin.toLowerCase()&&t.pathname.toLowerCase()===r.pathname.toLowerCase()}catch{return!1}});if(t.length===1)return{matchedElement:t[0],matchConfidence:`EXACT`,targetUrl:n,reason:`Single exact destination link matched on page.`};if(t.length>1)return{matchedElement:null,matchConfidence:`AMBIGUOUS`,targetUrl:n,reason:`Multiple links match target URL. Applying Safe Uncertainty Rule (no arbitrary blocking).`}}}if(n&&n.length>0){for(let t of n)if(t.target&&t.target.trim().startsWith(`http`)){let n=v(e,t.target);if(n.matchConfidence===`EXACT`)return{...n,actionId:t.actionId}}}return{matchedElement:null,matchConfidence:`NO_MATCH`,reason:`No element on the page matches the analyzed target.`}}var y=class{targetElement=null;currentPayload=null;isOverridden=!1;clickListener=null;callbacks;constructor(e){this.callbacks=e}attach(e,t){this.detach(),(t.decision===`PAUSE`||t.decision===`BLOCK`)&&(this.targetElement=e,this.currentPayload=t,this.isOverridden=!1,this.clickListener=e=>{if(this.isOverridden||!this.targetElement||!this.currentPayload)return;let t=this.targetElement,n=e.target;n&&(n===t||t.contains(n))&&(e.preventDefault(),e.stopPropagation(),this.callbacks.onTargetTriggered(t,this.currentPayload))},document.addEventListener(`click`,this.clickListener,!0))}setOverridden(e){this.isOverridden=e}getIsOverridden(){return this.isOverridden}getTargetElement(){return this.targetElement}detach(){this.clickListener&&=(document.removeEventListener(`click`,this.clickListener,!0),null),this.targetElement=null,this.currentPayload=null,this.isOverridden=!1}},b=new class{overlay;interceptor;currentPayload=null;isOverridden=!1;active=!1;constructor(){this.overlay=new _({onDismiss:()=>{(this.currentPayload?.decision===`INFORM`||this.currentPayload?.decision===`WARN`)&&(this.active=!1)},onOpenAnalysis:e=>{this.openWebAppAnalysis(e)},onConfirmOverride:e=>{this.handleOverrideConfirmed(e)},onReturn:()=>{}}),this.interceptor=new y({onTargetTriggered:(e,t)=>{this.overlay.render(t)}})}showIntervention(e){if(!e||e.decision===`ALLOW`){this.cleanup();return}if(this.currentPayload=e,this.active=!0,this.isOverridden=!1,e.decision===`PAUSE`||e.decision===`BLOCK`){let t=v(document,e.targetUrl,e.actions);t.matchConfidence===`EXACT`&&t.matchedElement?this.interceptor.attach(t.matchedElement,e):this.interceptor.detach()}else this.interceptor.detach();this.overlay.render(e)}hideIntervention(){this.overlay.destroy(),(this.currentPayload?.decision===`INFORM`||this.currentPayload?.decision===`WARN`)&&(this.active=!1)}handleOverrideConfirmed(e){this.isOverridden=!0,this.interceptor.setOverridden(!0),this.active=!1}openWebAppAnalysis(t){if(typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage){let n={type:`OPEN_NIVESH_APP`,requestId:e(),timestamp:new Date().toISOString(),payload:{analysisId:t}};chrome.runtime.sendMessage(n)}else this.currentPayload?.webAppUrl&&window.open(this.currentPayload.webAppUrl,`_blank`)}getState(){return{active:this.active,decision:this.currentPayload?.decision||null,analysisId:this.currentPayload?.analysisId||null,targetUrl:this.currentPayload?.targetUrl,overridden:this.isOverridden,blockedTargetUrl:this.currentPayload?.decision===`BLOCK`?this.currentPayload.targetUrl:void 0,timestamp:this.currentPayload?.timestamp}}getOverlay(){return this.overlay}getInterceptor(){return this.interceptor}cleanup(){this.overlay.destroy(),this.interceptor.detach(),this.currentPayload=null,this.isOverridden=!1,this.active=!1}};function x(){typeof chrome<`u`&&chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener((e,n,r)=>{if(!e||typeof e!=`object`||!e.type)return!1;if(e.type===`GET_PAGE_CONTEXT`){try{let t=a();r({success:!0,requestId:e.requestId,data:{context:t}})}catch(t){r({success:!1,requestId:e.requestId,error:{code:`CONTEXT_EXTRACTION_FAILED`,message:t instanceof Error?t.message:`Failed to extract page context.`}})}return!0}if(e.type===`CHECK_SELECTION`){try{let t=g(window),n=t.isValid&&!!t.sanitizedText,i=n?t.sanitizedText.slice(0,100):void 0;r({success:!0,requestId:e.requestId,data:{hasSelection:n,length:t.sanitizedText?t.sanitizedText.length:0,previewText:i}})}catch{r({success:!0,requestId:e.requestId,data:{hasSelection:!1}})}return!0}if(e.type===`DO_CAPTURE`){let n=e;if(!n.payload||!n.payload.sourceType)return r({success:!1,requestId:e.requestId,error:{code:`INVALID_PAYLOAD`,message:`DO_CAPTURE message requires a valid payload with sourceType.`}}),!0;let{captureId:i,sourceType:a}=n.payload;try{let n=window.location.href||``,o=window.location.origin||``,s=(document.title||``).trim().slice(0,500),c=t(n),l;if(a===`SELECTED_TEXT`){let e=g(window);l={captureId:i,sourceType:`SELECTED_TEXT`,status:e.status,text:e.sanitizedText,displayUrl:c,pageTitle:s,pageOrigin:o,timestamp:new Date().toISOString(),contentLength:e.sanitizedText?e.sanitizedText.length:0,sanitized:!0,error:e.error}}else if(a===`CURRENT_PAGE`){let e=h(document);l={captureId:i,sourceType:`CURRENT_PAGE`,status:e.status,text:e.sanitizedText,url:n,displayUrl:c,pageTitle:s,pageOrigin:o,timestamp:new Date().toISOString(),contentLength:e.sanitizedText?e.sanitizedText.length:0,sanitized:!0,error:e.error}}else l={captureId:i,sourceType:`URL`,status:`CAPTURED`,url:n,displayUrl:c,pageTitle:s,pageOrigin:o,timestamp:new Date().toISOString(),contentLength:n.length,sanitized:!0};r({success:l.status===`CAPTURED`,requestId:e.requestId,data:{capture:l},error:l.status===`CAPTURED`?void 0:{code:l.status,message:l.error||`Failed to capture content.`}})}catch(t){r({success:!1,requestId:e.requestId,error:{code:`CAPTURE_FAILED`,message:t instanceof Error?t.message:`Unexpected error during page capture.`}})}return!0}if(e.type===`SHOW_INTERVENTION`){try{let t=e;b.showIntervention(t.payload),r({success:!0,requestId:e.requestId,data:b.getState()})}catch(t){r({success:!1,requestId:e.requestId,error:{code:`INTERVENTION_FAILED`,message:t instanceof Error?t.message:`Failed to display intervention.`}})}return!0}return e.type===`HIDE_INTERVENTION`?(b.hideIntervention(),r({success:!0,requestId:e.requestId,data:b.getState()}),!0):e.type===`GET_PROTECTION_STATE`&&(r({success:!0,requestId:e.requestId,data:b.getState()}),!0)})}typeof window<`u`&&x();